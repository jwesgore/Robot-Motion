To run 
	Question 1, run IVP.py
	Question 2, run RRT.py
	Bonus RRT Star, run RRT_Star.py

Program was made using python 3.10 and Matplotlib 

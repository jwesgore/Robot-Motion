Program was made using Python 3
 - matplotlib is REQUIRED to run the program to generate the visuals
 - matplotlib can be installed using pip with the command "python -m pip install matplotlib"

 To run the program open a terminal at the folder location 
    run: python '.\Assignment 2.py'

The program will prompt you with 5 options
1. Will generate the graham scan visual for q3
2. Will generate the graham scan and minkowski distance visual for q4
3. Will ask you for X and Y values to test on q3, as well as plotting it and printing if it is in the c-space
4. Will ask you for X and Y values to test on q4, as well as plotting it and printing if it is in the c-space
5. Will exit the program